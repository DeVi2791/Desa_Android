package nextu.mensaje;

public class Imagen {
    private String nombre;
}
