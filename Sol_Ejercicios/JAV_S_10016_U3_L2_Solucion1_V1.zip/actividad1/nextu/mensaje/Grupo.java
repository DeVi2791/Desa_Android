package nextu.mensaje;

public class Grupo {
    private String nombre;
    private Usuario[] usuario;
    
    public void agregarMiembro(Usuario usuario){
    }
}
