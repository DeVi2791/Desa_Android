package nextu.mensaje;

public class Usuario {
    private String apodo;
    public void enviarMensaje(){}
}
