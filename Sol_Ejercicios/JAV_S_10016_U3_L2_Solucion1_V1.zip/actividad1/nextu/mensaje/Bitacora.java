package nextu.mensaje;

public class Bitacora {
    public void registrar(){}
}
