package nextu.mensaje;

public class AplicacionMensaje {
    private Bitacora bitacora;
    private Usuario[] usuarios;
    private Grupo[] grupos;
    
}   
