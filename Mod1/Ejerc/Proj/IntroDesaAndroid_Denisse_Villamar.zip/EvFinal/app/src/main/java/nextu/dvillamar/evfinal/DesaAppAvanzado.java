package nextu.dvillamar.evfinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DesaAppAvanzado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desa_app_avanzado);
    }
}
