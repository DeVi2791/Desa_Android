package com.example.nextu.promedio;

/**
 * Created by Next University
 */
public class Calculador {

    public void formula(int nota1, int nota2, int  nota3){

        int pormedio = (nota1+nota2+nota3)/3;


    }

}
