package nextu.mensaje;

public class Mensaje {
    private String fechaHora;
    private Usuario emisor;
    private Usuario receptor;
    private String texto;
}
